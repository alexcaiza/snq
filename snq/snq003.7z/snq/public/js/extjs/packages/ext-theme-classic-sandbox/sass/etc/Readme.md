# /sass/etc

This folder contains miscellaneous SASS files. Unlike `"/sass/etc"`, these files
need to be used explicitly.
