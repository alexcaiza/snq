# ext-locale-en/overrides

This folder contains overrides which will automatically be required by package users.
